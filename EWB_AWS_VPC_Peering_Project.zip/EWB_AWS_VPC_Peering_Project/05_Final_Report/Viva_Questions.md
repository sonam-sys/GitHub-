# Viva Questions and Simple Answers

1. **What is a VPC?** A logically isolated virtual network in AWS.
2. **What is VPC peering?** A private network connection between two VPCs.
3. **Why must VPC CIDRs not overlap?** AWS cannot route overlapping address ranges unambiguously through peering.
4. **Why are two routes needed?** The request needs a forward path and the reply needs a return path.
5. **Why is App-B private?** It has no public IPv4 and is reached through the bastion/peering path.
6. **What is a bastion host?** A controlled entry server used to administer private instances.
7. **What is ProxyJump?** An SSH feature that uses a jump host to reach another SSH server.
8. **Why does App-B see SSH source 10.10.1.10?** The bastion opens a separate SSH connection to App-B.
9. **Does Active peering alone guarantee ping?** No. Routes and security rules must also allow the traffic.
10. **Does peering give VPC B internet access through VPC A's IGW?** No.
11. **What does /32 mean?** One exact IPv4 address.
12. **Are security groups stateful?** Yes, response traffic for allowed connections is automatically allowed.
13. **What is a local route?** The automatic route for communication within the VPC CIDR.
14. **Is VPC peering transitive?** No. A-B and A-C do not automatically provide B-C connectivity.
15. **Why clean up?** To avoid unnecessary AWS charges and remove lab resources safely.
