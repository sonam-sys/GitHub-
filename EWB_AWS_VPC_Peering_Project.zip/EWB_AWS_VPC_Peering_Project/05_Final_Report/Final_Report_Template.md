# AWS VPC Peering Project Report

**Student Name:** [Fill in]  
**Batch:** [Fill in]  
**Course:** AWS Architect Associate  
**Project:** EWB AWS VPC Peering  
**AWS Region:** ap-south-1 (Mumbai)  
**Completion Date:** [Fill in]

## 1. Objective
To establish private IPv4 communication between two non-overlapping VPCs using VPC Peering, while keeping application instances private and providing administrative SSH access through a public bastion host.

## 2. Architecture
Insert your completed architecture diagram and explain:
- Laptop -> Bastion (public IPv4, SSH)
- Bastion -> App-A and App-B (private SSH via ProxyJump)
- App-A <-> App-B (private IP traffic over VPC peering)

## 3. IP Address Plan
Insert completed resource_inventory.csv details, including actual resource IDs and IP addresses.

## 4. Network Configuration
Describe VPCs, subnets, Internet Gateway, route tables, subnet associations and peering routes. Insert screenshots of all three route tables.

## 5. Security Configuration
Document the inbound rules for ewb-sg-bastion, ewb-sg-app-a and ewb-sg-app-b. Confirm SSH/ICMP are not open to 0.0.0.0/0.

## 6. EC2 Configuration
List the three Amazon Linux 2023 instances, instance types, IDs, private IPs and bastion public IP. Confirm App-A and App-B have no public IPv4.

## 7. Testing and Results
For each test include command, source host, destination, actual result and screenshot:
- Baseline failure before peering
- Forward ping success
- Reverse ping success
- SSH to App-B through bastion
- Private-instance public-IP isolation
- Controlled ICMP failure and recovery

Do not claim success unless your own output proves it.

## 8. Forward and Return Traffic Path
Explain that App-A uses its private route table to send 10.20.0.0/16 to the peering connection. App-B's route table sends 10.10.0.0/16 back through the same peering connection. Security groups allow only the required SSH and ICMP sources.

## 9. Troubleshooting
Summarize issues encountered and the actual fix applied.

## 10. Learning Outcomes
[Write what you learned about CIDR, VPCs, subnets, routes, security groups, bastion hosts and peering.]

## 11. Cleanup
Insert evidence that instances, leftover volumes/snapshots, peer routes, peering, security groups, subnets, route tables, IGW and VPCs were removed. Mention billing check.

## 12. Conclusion
[Summarize the verified outcome. State any tests that could not be completed.]

## Appendix
Add labelled screenshots. Never include private keys, passwords or access tokens.
