EWB AWS VPC PEERING PROJECT
===========================

This folder is organized around the 14-page EWB Cloud Labs workbook.

IMPORTANT:
- This is a ready-to-follow project pack, not proof that AWS resources have already
  been deployed. AWS account actions, resource IDs, screenshots and test outputs
  must come from your own AWS lab account.
- Do not put passwords, access tokens or the .pem private key in this folder/report.
- AWS EC2, EBS and public IPv4 resources may incur charges. Check pricing/credits.
- Do not create a NAT Gateway for this lab.

START HERE:
1. Open 01_Project_Guide/Project_Steps.md
2. Follow steps in order in AWS Mumbai (ap-south-1).
3. Save real screenshots in 04_Evidence_Screenshots.
4. Fill actual IDs and test results in 05_Final_Report/Final_Report_Template.md.
5. Do cleanup only after saving evidence.
