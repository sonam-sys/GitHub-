# EWB AWS VPC Peering — Complete Build Guide

## Goal
Connect two non-overlapping VPCs privately using VPC Peering. Keep both app servers private.
Use one public bastion in VPC A for SSH administration.

## Fixed design (AWS Region: Mumbai / ap-south-1)
| Resource | Name | CIDR / Private IP |
|---|---|---|
| VPC A | ewb-vpc-a | 10.10.0.0/16 |
| Public subnet A | ewb-a-public | 10.10.1.0/24 |
| Private subnet A | ewb-a-private | 10.10.2.0/24 |
| VPC B | ewb-vpc-b | 10.20.0.0/16 |
| Private subnet B | ewb-b-private | 10.20.1.0/24 |
| Bastion | ewb-bastion | 10.10.1.10 + public IPv4 |
| App A | ewb-app-a | 10.10.2.10; NO public IPv4 |
| App B | ewb-app-b | 10.20.1.10; NO public IPv4 |
| Internet Gateway | ewb-igw-a | attach to VPC A |
| Peering | ewb-a-b-peer | record actual pcx- ID |
| Key pair | ewb-lab | keep .pem on your laptop only |

Tag created resources: Project=EWB-VPC-Peering and Student=<your name>.
Record actual VPC, subnet, route table, instance and peering IDs.

## Step 1 — Create VPC A
1. VPC Console > Your VPCs > Create VPC > VPC only.
2. Name ewb-vpc-a; IPv4 CIDR 10.10.0.0/16; no IPv6; tenancy Default.
3. Create subnets in VPC A: ewb-a-public 10.10.1.0/24 and ewb-a-private 10.10.2.0/24.
4. Create ewb-igw-a and attach it to ewb-vpc-a.
5. Create ewb-rt-a-public. Explicitly associate ewb-a-public.
6. Add 0.0.0.0/0 -> ewb-igw-a. Keep local route.
7. Create ewb-rt-a-private. Explicitly associate ewb-a-private. Keep ONLY local route for now.
8. Disable auto-assign public IPv4 on private subnet.

Checkpoint 1: screenshot both subnet associations, public default route and private route table.

## Step 2 — Create VPC B
1. Create ewb-vpc-b with 10.20.0.0/16.
2. Create ewb-b-private with 10.20.1.0/24.
3. Create ewb-rt-b-private; associate ewb-b-private; keep local route.
4. Disable auto-assign public IPv4. Do not create an Internet Gateway for VPC B.

## Step 3 — Security groups
Create the groups in their respective VPCs. Keep default outbound allow-all for this lab.
Use default allow-all Network ACLs. Do NOT expose SSH or ICMP to 0.0.0.0/0.

- ewb-sg-bastion (VPC A): inbound SSH TCP 22 from YOUR_CURRENT_PUBLIC_IPV4/32.
- ewb-sg-app-a (VPC A):
  - SSH TCP 22 from 10.10.1.10/32 (bastion)
  - Custom ICMP IPv4 Echo Request (type 8, code 0) from 10.20.1.10/32 (App B)
- ewb-sg-app-b (VPC B):
  - SSH TCP 22 from 10.10.1.10/32 (bastion)
  - Custom ICMP IPv4 Echo Request (type 8, code 0) from 10.10.2.10/32 (App A)

Security groups are stateful. Replies to allowed connections are automatically permitted.
The source IP for App-B SSH via ProxyJump is the bastion private IP.

## Step 4 — Launch three EC2 instances
1. Create RSA key pair ewb-lab and download .pem. Never upload/copy it to EC2.
2. Use Amazon Linux 2023 and instructor-approved small x86 type (example t3.micro).
3. Check displayed pricing/credits. Use small root disk and delete-on-termination.
4. Launch:
   - ewb-bastion: VPC A / ewb-a-public / private IP 10.10.1.10 / public IPv4 enabled / ewb-sg-bastion
   - ewb-app-a: VPC A / ewb-a-private / private IP 10.10.2.10 / public IPv4 disabled / ewb-sg-app-a
   - ewb-app-b: VPC B / ewb-b-private / private IP 10.20.1.10 / public IPv4 disabled / ewb-sg-app-b
5. Wait for running and passed status checks.
6. Record all instance IDs, private IPs and bastion public IP. Confirm both app public IPv4 fields are blank.

Checkpoint 2: screenshot instance list/details with public/private IP fields.

## Step 5 — SSH from your laptop
Use OpenSSH (Windows users can use WSL). Follow 03_Commands/ssh_config_template.txt.
Set key permission to 400. Test bastion, then App A. From App A, run baseline:
ping -c 4 10.20.1.10
Before peering and peer routes, expected: no replies. Save real output.

## Step 6 — Create VPC Peering
1. VPC Console > Peering connections > Create peering connection.
2. Name ewb-a-b-peer; requester ewb-vpc-a; account My account; region This Region; accepter ewb-vpc-b.
3. Select new connection > Actions > Accept request.
4. Wait for Active. Record actual pcx- ID and both VPC IDs/CIDRs.

Checkpoint 3: screenshot name, Active status and both VPC IDs.

## Step 7 — Add routes (both directions)
Keep AWS local routes. Add:
- ewb-rt-a-private (associated to ewb-a-private): 10.20.0.0/16 -> actual pcx-ID
- ewb-rt-b-private (associated to ewb-b-private): 10.10.0.0/16 -> actual pcx-ID
- ewb-rt-a-public (associated to ewb-a-public): 10.20.0.0/16 -> actual pcx-ID
The public route table must also retain 0.0.0.0/0 -> ewb-igw-a.
Do not add an internet default route to either private route table.

Checkpoint 4: screenshot all three route tables AND subnet associations. Return route is essential.

## Step 8 — Validate
Run the commands in 03_Commands/connectivity_tests.txt and save actual terminal screenshots:
1. Baseline before peering: App A -> App B ping fails.
2. Forward: App A ping App B private IP succeeds (4 replies, 0% loss expected).
3. Reverse: App B ping App A private IP succeeds (4 replies, 0% loss expected).
4. Private SSH: laptop command `ssh ewb-app-b` opens App B through bastion.
5. Isolation: App A and App B have no public IPv4.
6. Controlled failure: remove ONLY App-B inbound ICMP Echo Request rule from 10.10.2.10/32; repeat App-A ping and confirm failure; restore exact rule and confirm recovery. Keep SSH rule.

Do not write expected results as if they were actual results. Record what your AWS environment really shows.

## Step 9 — Troubleshooting
- Bastion SSH timeout: check current bastion public IP, your current public IP /32, public subnet association and IGW default route.
- App-A SSH fails: check App-A IP, TCP 22 from 10.10.1.10/32, key, ec2-user and instance state.
- App-B SSH fails: check public subnet route 10.20.0.0/16 -> pcx-ID, VPC B return route, App-B SSH source bastion private IP.
- Ping fails: check both private route tables, Active peering, correct pcx-ID, destination ICMP rule and actual IPs.
- Peering creation fails: check all primary and secondary VPC CIDRs for overlap.
- Permission denied (publickey): check key pair, local IdentityFile and ec2-user.
- Custom ACL issue: inspect both directions, ICMP and SSH ephemeral return ports. Lab assumes default ACLs.

## Step 10 — Cleanup (after evidence is saved)
1. Terminate ewb-bastion, ewb-app-a and ewb-app-b.
2. Confirm lab EBS volumes deleted; remove leftovers/snapshots. Release any Elastic IP.
3. Remove unused lab key pair and local lab key if no longer needed.
4. Delete peer routes and ewb-a-b-peer.
5. Delete lab security groups after instance ENIs disappear.
6. Remove subnet associations as needed; delete lab subnets and custom route tables.
7. Detach/delete ewb-igw-a; delete both lab VPCs.
8. Filter by project tag and check EC2, EBS, public IPv4 and VPC resources. Check Billing (usage reporting may lag). Capture cleanup evidence.

## Core concepts for viva
- VPC peering is a one-to-one private connection between two VPCs.
- VPC CIDR blocks must not overlap.
- Peering is non-transitive: A-B and A-C do not automatically connect B-C.
- Both forward and return routes are required.
- Peering does not give VPC B internet access through VPC A's IGW.
- Security groups control which traffic is allowed; they are stateful.
- ProxyJump makes the bastion open a separate SSH connection to the private destination.
